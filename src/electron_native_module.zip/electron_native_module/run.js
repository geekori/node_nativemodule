var exec = require('child_process').exec;
free = exec('electron .');